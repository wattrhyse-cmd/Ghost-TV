import React, { useState, useEffect, useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import { User, Lock, Server, PlayCircle, Search, AlertCircle, Sparkles, Send, Tv, Play, Info, ArrowLeft, Star, Clock, Wifi, Check, Palette } from 'lucide-react';

import VideoPlayer from './components/VideoPlayer';
import Sidebar from './components/Sidebar';
import { LoginCredentials, StreamItem, StreamCategory, AppView, StreamType, AppTheme } from './types';
import { MOCK_CATEGORIES, MOCK_STREAMS, APP_THEMES } from './constants';
import { getAIRecommendations } from './services/geminiService';

const App: React.FC = () => {
  // --- State ---
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentView, setCurrentView] = useState<AppView>('DASHBOARD');
  const [currentTheme, setCurrentTheme] = useState<AppTheme>(APP_THEMES[0]);
  
  // Login Form State
  const [credentials, setCredentials] = useState<LoginCredentials>({ url: '', username: '', password: '' });
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Data State
  const [categories, setCategories] = useState<StreamCategory[]>([]);
  const [streams, setStreams] = useState<StreamItem[]>([]);
  
  // Player/Browsing State
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedStream, setSelectedStream] = useState<StreamItem | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // UI State
  const [heroImage, setHeroImage] = useState<string>('');

  // AI Chat State
  const [aiQuery, setAiQuery] = useState('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  // --- Effects ---

  useEffect(() => {
     // Set a random hero image from movies
     const movies = MOCK_STREAMS.filter(s => s.stream_type === StreamType.MOVIE);
     if (movies.length > 0) {
         setHeroImage(movies[Math.floor(Math.random() * movies.length)].stream_icon || '');
     }
  }, [streams]);

  // Mock Login Process
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    setLoginError('');

    setTimeout(() => {
      if (credentials.username && credentials.password && credentials.url) {
        completeLogin();
      } else {
        setLoginError('Please fill in all fields');
        setIsLoggingIn(false);
      }
    }, 1500);
  };

  const loadDemo = () => {
    setIsLoggingIn(true);
    setTimeout(() => {
        setCredentials({
            url: 'http://demo-iptv.com',
            username: 'demo_user',
            password: 'demo_password'
        });
        completeLogin();
    }, 1000);
  };

  const completeLogin = () => {
    setIsAuthenticated(true);
    setCategories(MOCK_CATEGORIES);
    setStreams(MOCK_STREAMS);
    setIsLoggingIn(false);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCredentials({ url: '', username: '', password: '' });
    setSelectedStream(null);
    setCurrentView('LOGIN');
  };

  const handleStreamProgress = (progress: number) => {
    if (selectedStream) {
        setStreams(prevStreams => 
            prevStreams.map(s => 
                s.stream_id === selectedStream.stream_id 
                ? { ...s, progress } 
                : s
            )
        );
    }
  };

  // --- Filtering Logic ---
  
  const filteredStreams = useMemo(() => {
    let typeFilter = '';
    if (currentView === 'LIVE') typeFilter = StreamType.LIVE;
    if (currentView === 'MOVIES') typeFilter = StreamType.MOVIE;
    if (currentView === 'SERIES') typeFilter = StreamType.SERIES;

    return streams.filter(stream => {
      const matchesType = typeFilter ? stream.stream_type === typeFilter : true;
      const matchesCategory = selectedCategory ? stream.category_id === selectedCategory : true;
      const matchesSearch = stream.name.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesType && matchesCategory && matchesSearch;
    });
  }, [streams, currentView, selectedCategory, searchTerm]);

  const activeCategories = useMemo(() => {
     return categories.filter(cat => {
         let typeFilter = '';
         if (currentView === 'LIVE') typeFilter = StreamType.LIVE;
         if (currentView === 'MOVIES') typeFilter = StreamType.MOVIE;
         if (currentView === 'SERIES') typeFilter = StreamType.SERIES;
         return streams.some(s => s.category_id === cat.category_id && s.stream_type === typeFilter);
     });
  }, [categories, streams, currentView]);

  const continueWatchingItems = useMemo(() => {
    return streams.filter(s => s.progress && s.progress > 0 && s.progress < 98);
  }, [streams]);

  // --- Helpers ---
  const getGreeting = () => {
      const hour = new Date().getHours();
      if (hour < 12) return 'Good Morning';
      if (hour < 18) return 'Good Afternoon';
      return 'Good Evening';
  };

  const handleAskAI = async () => {
    if (!aiQuery.trim()) return;
    setAiLoading(true);
    const response = await getAIRecommendations(aiQuery, streams);
    setAiResponse(response);
    setAiLoading(false);
  };

  // --- Render Sections ---

  if (!isAuthenticated) {
    return (
      <div className={`min-h-screen ${currentTheme.colors.background} flex items-center justify-center p-4 relative overflow-hidden font-sans transition-colors duration-500`}>
        {/* Modern Background */}
        <div className="absolute inset-0 overflow-hidden">
            <div className={`absolute -top-[30%] -left-[10%] w-[800px] h-[800px] ${currentTheme.colors.bgAccent} opacity-20 rounded-full blur-[120px] animate-pulse`}></div>
            <div className="absolute bottom-[0%] -right-[10%] w-[600px] h-[600px] bg-indigo-600/20 rounded-full blur-[100px]"></div>
        </div>

        <div className="w-full max-w-md bg-white/5 backdrop-blur-2xl p-10 rounded-3xl border border-white/10 shadow-2xl z-10 relative">
            <div className="text-center mb-10">
                <div className={`w-20 h-20 bg-gradient-to-tr ${currentTheme.colors.gradient} rounded-2xl mx-auto flex items-center justify-center mb-6 shadow-xl transform rotate-3 hover:rotate-0 transition-all duration-500`}>
                    <Tv className="text-white w-10 h-10" />
                </div>
                <h1 className="text-3xl font-bold text-white mb-2 tracking-tight">StreamGenie</h1>
                <p className="text-slate-400 text-sm font-medium">Next-Generation IPTV Experience</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-5">
                <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Server URL</label>
                    <div className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <Server className={`h-5 w-5 text-slate-500 group-focus-within:${currentTheme.colors.textAccent} transition-colors`} />
                        </div>
                        <input 
                            type="url" 
                            className={`block w-full pl-11 pr-4 py-3.5 bg-slate-900/50 border border-slate-700/50 rounded-xl text-sm placeholder-slate-500 focus:outline-none focus:${currentTheme.colors.borderAccent} focus:ring-1 focus:ring-opacity-50 text-white transition-all`} 
                            placeholder="http://provider.com:8080"
                            value={credentials.url}
                            onChange={(e) => setCredentials({...credentials, url: e.target.value})}
                        />
                    </div>
                </div>

                <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Username</label>
                    <div className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <User className={`h-5 w-5 text-slate-500 group-focus-within:${currentTheme.colors.textAccent} transition-colors`} />
                        </div>
                        <input 
                            type="text" 
                            className={`block w-full pl-11 pr-4 py-3.5 bg-slate-900/50 border border-slate-700/50 rounded-xl text-sm placeholder-slate-500 focus:outline-none focus:${currentTheme.colors.borderAccent} focus:ring-1 focus:ring-opacity-50 text-white transition-all`} 
                            placeholder="Username"
                            value={credentials.username}
                            onChange={(e) => setCredentials({...credentials, username: e.target.value})}
                        />
                    </div>
                </div>

                <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Password</label>
                    <div className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <Lock className={`h-5 w-5 text-slate-500 group-focus-within:${currentTheme.colors.textAccent} transition-colors`} />
                        </div>
                        <input 
                            type="password" 
                            className={`block w-full pl-11 pr-4 py-3.5 bg-slate-900/50 border border-slate-700/50 rounded-xl text-sm placeholder-slate-500 focus:outline-none focus:${currentTheme.colors.borderAccent} focus:ring-1 focus:ring-opacity-50 text-white transition-all`} 
                            placeholder="••••••••"
                            value={credentials.password}
                            onChange={(e) => setCredentials({...credentials, password: e.target.value})}
                        />
                    </div>
                </div>

                {loginError && (
                    <div className="flex items-center text-red-400 text-xs bg-red-500/10 p-3 rounded-lg border border-red-500/20">
                        <AlertCircle className="w-4 h-4 mr-2 flex-shrink-0" />
                        {loginError}
                    </div>
                )}

                <button 
                    type="submit" 
                    disabled={isLoggingIn}
                    className={`w-full bg-gradient-to-r ${currentTheme.colors.gradient} hover:opacity-90 text-white font-bold py-4 rounded-xl shadow-lg transition-all transform active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed`}
                >
                    {isLoggingIn ? 'Authenticating...' : 'Secure Login'}
                </button>
            </form>

            <div className="mt-8 text-center">
                <button 
                    onClick={loadDemo}
                    className={`text-xs text-slate-500 hover:${currentTheme.colors.textAccent} transition-colors`}
                >
                    Try Demo Account
                </button>
            </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`flex h-screen ${currentTheme.colors.background} text-white overflow-hidden font-sans transition-colors duration-500`}>
      <Sidebar 
          currentView={currentView} 
          onChangeView={(v) => { setCurrentView(v); setSelectedCategory(null); }} 
          onLogout={handleLogout} 
          theme={currentTheme}
      />
      
      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        
        {/* Premium Header */}
        <header className={`h-20 flex items-center justify-between px-8 bg-gradient-to-b from-black/20 to-transparent backdrop-blur-md z-20 border-b border-white/5`}>
            <div>
                <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                    {currentView === 'DASHBOARD' && (
                        <>
                           <span className={`text-transparent bg-clip-text bg-gradient-to-r ${currentTheme.colors.gradient}`}>{getGreeting()}</span>, {credentials.username || 'User'}
                        </>
                    )}
                    {currentView === 'LIVE' && <><span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span> Live TV</>}
                    {currentView === 'MOVIES' && 'Movies'}
                    {currentView === 'SERIES' && 'Series'}
                    {currentView === 'AI_SEARCH' && 'AI Curator'}
                    {currentView === 'SETTINGS' && 'Settings'}
                </h2>
                <p className="text-xs text-slate-500 font-medium">
                    {currentView === 'DASHBOARD' ? 'Welcome to your streaming hub' : 
                     currentView === 'SETTINGS' ? 'Customize your experience' :
                     'Browse your content library'}
                </p>
            </div>
            
            <div className="flex items-center space-x-6">
                 {(currentView === 'LIVE' || currentView === 'MOVIES' || currentView === 'SERIES') && (
                    <div className="relative group">
                        <Search className={`absolute left-3 top-2.5 text-slate-500 w-4 h-4 group-focus-within:${currentTheme.colors.textAccent} transition-colors`} />
                        <input 
                            type="text" 
                            placeholder="Search..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className={`bg-slate-800/50 border border-slate-700/50 rounded-full py-2 pl-9 pr-4 text-sm focus:outline-none focus:${currentTheme.colors.borderAccent} focus:bg-slate-800 transition-all w-48 focus:w-64`}
                        />
                    </div>
                )}
                
                <div className="flex items-center space-x-4 border-l border-white/10 pl-6">
                    <div className="text-right hidden md:block">
                        <div className="text-xs font-bold text-white">Pro Plan</div>
                        <div className={`text-[10px] ${currentTheme.colors.textAccent} flex items-center justify-end gap-1`}>
                            <Wifi className="w-3 h-3" /> Connected
                        </div>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-slate-700 to-slate-800 border border-white/10 flex items-center justify-center">
                        <User className="w-5 h-5 text-slate-400" />
                    </div>
                </div>
            </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-hidden relative">
            
            {/* --- DASHBOARD VIEW --- */}
            {currentView === 'DASHBOARD' && (
                <div className="h-full overflow-y-auto p-8 custom-scrollbar">
                    {/* Hero Section */}
                    <div className="relative w-full h-64 md:h-80 rounded-3xl overflow-hidden mb-8 shadow-2xl shadow-black/50 group">
                        <div className="absolute inset-0 bg-cover bg-center transition-transform duration-1000 group-hover:scale-105" style={{ backgroundImage: `url(${heroImage || 'https://images.unsplash.com/photo-1593784653256-42d3a3d528b6?auto=format&fit=crop&q=80&w=2000'})` }} />
                        <div className={`absolute inset-0 bg-gradient-to-t ${currentTheme.colors.gradient.replace('from-', 'from-black ').replace('to-', 'to-black/10 ')} opacity-90`} />
                        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/50 to-transparent"></div>
                        
                        <div className="absolute bottom-0 left-0 p-8 w-full md:w-2/3">
                            <span className={`inline-block px-3 py-1 ${currentTheme.colors.iconBg} ${currentTheme.colors.textAccent} rounded-full text-xs font-bold mb-3 border border-white/10 backdrop-blur-sm`}>TRENDING NOW</span>
                            <h1 className="text-3xl md:text-5xl font-bold text-white mb-3">Unlimited Entertainment</h1>
                            <p className="text-slate-300 mb-6 line-clamp-2">Discover the latest movies, binge-worthy series, and live sports events all in one place. Your premium streaming experience starts here.</p>
                            <button onClick={() => setCurrentView('MOVIES')} className={`${currentTheme.colors.bgAccent} ${currentTheme.colors.bgAccentHover} text-white px-8 py-3 rounded-xl font-bold transition-all flex items-center gap-2 shadow-lg`}>
                                <Play className="w-5 h-5 fill-current" /> Watch Now
                            </button>
                        </div>
                    </div>

                    {/* Continue Watching Section */}
                    {continueWatchingItems.length > 0 && (
                        <div className="mb-10 animate-fadeIn">
                             <h3 className="text-lg font-bold text-white mb-4 flex items-center">
                                <Clock className={`w-5 h-5 ${currentTheme.colors.textAccent} mr-2`} /> Continue Watching
                             </h3>
                             <div className="flex gap-4 overflow-x-auto pb-6 custom-scrollbar">
                                {continueWatchingItems.map(item => (
                                   <div 
                                      key={item.stream_id}
                                      onClick={() => {
                                          setSelectedStream(item);
                                          setCurrentView(item.stream_type === StreamType.MOVIE ? 'MOVIES' : 'SERIES');
                                      }}
                                      className="flex-shrink-0 w-64 group cursor-pointer"
                                   >
                                        <div className={`relative aspect-video rounded-xl overflow-hidden ${currentTheme.colors.cardBg} shadow-lg border border-white/5 group-hover:${currentTheme.colors.borderAccent} transition-all`}>
                                            <img src={item.stream_icon} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                                            <div className="absolute inset-0 flex items-center justify-center">
                                                <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all transform scale-50 group-hover:scale-100">
                                                    <Play className="w-4 h-4 fill-white text-white" />
                                                </div>
                                            </div>
                                            
                                            {/* Progress Bar */}
                                            <div className="absolute bottom-0 left-0 right-0 h-1 bg-slate-700">
                                                <div 
                                                    className={`h-full ${currentTheme.colors.bgAccent}`}
                                                    style={{ width: `${item.progress}%` }}
                                                />
                                            </div>
                                        </div>
                                        <div className="mt-2 px-1">
                                            <h4 className="text-sm font-medium text-slate-200 truncate">{item.name}</h4>
                                            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                                                <span>{item.stream_type === StreamType.MOVIE ? 'Movie' : 'Series'}</span>
                                                <span>{item.progress}% left</span>
                                            </div>
                                        </div>
                                   </div>
                                ))}
                             </div>
                        </div>
                    )}

                    {/* Quick Access Cards */}
                    <h3 className="text-lg font-bold text-white mb-4 flex items-center"><Star className="w-4 h-4 text-yellow-500 mr-2 fill-current" /> Quick Access</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
                        <div onClick={() => setCurrentView('LIVE')} className={`cursor-pointer ${currentTheme.colors.cardBg} hover:bg-opacity-80 p-6 rounded-2xl border border-white/5 hover:${currentTheme.colors.borderAccent} transition-all hover:-translate-y-1 hover:shadow-xl group relative overflow-hidden`}>
                            <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                                <Tv className="w-24 h-24 text-rose-500" />
                            </div>
                            <div className="w-14 h-14 bg-rose-500/20 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-rose-500 transition-colors">
                                <Tv className="text-rose-500 group-hover:text-white w-7 h-7" />
                            </div>
                            <h3 className="text-xl font-bold text-white mb-1">Live TV</h3>
                            <p className="text-slate-400 text-xs">News, Sports & Events</p>
                        </div>

                        <div onClick={() => setCurrentView('MOVIES')} className={`cursor-pointer ${currentTheme.colors.cardBg} hover:bg-opacity-80 p-6 rounded-2xl border border-white/5 hover:${currentTheme.colors.borderAccent} transition-all hover:-translate-y-1 hover:shadow-xl group relative overflow-hidden`}>
                            <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                                <PlayCircle className="w-24 h-24 text-cyan-500" />
                            </div>
                            <div className="w-14 h-14 bg-cyan-500/20 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-cyan-500 transition-colors">
                                <PlayCircle className="text-cyan-500 group-hover:text-white w-7 h-7" />
                            </div>
                            <h3 className="text-xl font-bold text-white mb-1">Movies</h3>
                            <p className="text-slate-400 text-xs">Blockbusters & Classics</p>
                        </div>

                        <div onClick={() => setCurrentView('SERIES')} className={`cursor-pointer ${currentTheme.colors.cardBg} hover:bg-opacity-80 p-6 rounded-2xl border border-white/5 hover:${currentTheme.colors.borderAccent} transition-all hover:-translate-y-1 hover:shadow-xl group relative overflow-hidden`}>
                            <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                                <Tv className="w-24 h-24 text-purple-500" />
                            </div>
                            <div className="w-14 h-14 bg-purple-500/20 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-purple-500 transition-colors">
                                <Tv className="text-purple-500 group-hover:text-white w-7 h-7" />
                            </div>
                            <h3 className="text-xl font-bold text-white mb-1">Series</h3>
                            <p className="text-slate-400 text-xs">Binge-worthy Shows</p>
                        </div>

                        <div onClick={() => setCurrentView('AI_SEARCH')} className={`cursor-pointer ${currentTheme.colors.cardBg} hover:bg-opacity-80 p-6 rounded-2xl border border-white/5 hover:${currentTheme.colors.borderAccent} transition-all hover:-translate-y-1 hover:shadow-xl group relative overflow-hidden md:col-span-3 lg:col-span-1`}>
                            <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                                <Sparkles className="w-24 h-24 text-emerald-500" />
                            </div>
                            <div className="w-14 h-14 bg-emerald-500/20 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-emerald-500 transition-colors">
                                <Sparkles className="text-emerald-500 group-hover:text-white w-7 h-7" />
                            </div>
                            <h3 className="text-xl font-bold text-white mb-1">AI Curator</h3>
                            <p className="text-slate-400 text-xs">Smart Recommendations</p>
                        </div>
                    </div>
                </div>
            )}

            {/* --- LIVE TV VIEW (Split Layout) --- */}
            {currentView === 'LIVE' && (
                <div className="flex h-full">
                    {/* Categories */}
                    <div className={`w-64 ${currentTheme.colors.sidebar} border-r border-slate-800 overflow-y-auto flex-shrink-0`}>
                        <div className="p-4">
                            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4 px-2">Categories</h3>
                            <div className="space-y-1">
                                <button
                                    onClick={() => setSelectedCategory(null)}
                                    className={`w-full text-left px-4 py-3 rounded-xl text-sm font-medium transition-all ${!selectedCategory ? `bg-gradient-to-r ${currentTheme.colors.gradient} text-white shadow-lg` : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
                                >
                                    All Channels
                                </button>
                                {activeCategories.map(cat => (
                                    <button
                                        key={cat.category_id}
                                        onClick={() => setSelectedCategory(cat.category_id)}
                                        className={`w-full text-left px-4 py-3 rounded-xl text-sm font-medium transition-all ${selectedCategory === cat.category_id ? `bg-gradient-to-r ${currentTheme.colors.gradient} text-white shadow-lg` : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
                                    >
                                        {cat.category_name}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Channel List */}
                    <div className={`${selectedStream ? 'hidden xl:block w-80' : 'flex-1'} ${currentTheme.colors.cardBg} border-r border-slate-800 overflow-y-auto flex-shrink-0 transition-all`}>
                        <div className="p-2">
                             {filteredStreams.map(stream => (
                                <div 
                                    key={stream.stream_id}
                                    onClick={() => setSelectedStream(stream)}
                                    className={`p-3 mb-1 rounded-xl cursor-pointer transition-all flex items-center gap-3 group ${selectedStream?.stream_id === stream.stream_id ? `bg-slate-700/50 border-l-4 ${currentTheme.colors.borderAccent}` : 'hover:bg-slate-700/30 border-l-4 border-transparent'}`}
                                >
                                    <div className="w-10 h-10 bg-black rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden border border-slate-700">
                                         <img src={stream.stream_icon} alt="" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }} />
                                         <span className="text-[10px] text-slate-600 font-bold absolute">TV</span>
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <h4 className={`font-medium text-sm truncate ${selectedStream?.stream_id === stream.stream_id ? 'text-white' : 'text-slate-300 group-hover:text-white'}`}>{stream.name}</h4>
                                        <div className="flex items-center text-[10px] text-slate-500 mt-0.5">
                                            <span className="bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700 mr-2">{stream.num}</span>
                                            <span>Live</span>
                                        </div>
                                    </div>
                                    {selectedStream?.stream_id === stream.stream_id && <div className={`w-2 h-2 rounded-full ${currentTheme.colors.bgAccent} animate-pulse`}></div>}
                                </div>
                            ))}
                        </div>
                    </div>
                    
                    {/* Player */}
                    {selectedStream ? (
                        <div className="flex-1 bg-black flex flex-col relative">
                            <div className="flex-1 relative">
                                <VideoPlayer key={selectedStream.stream_id} src={selectedStream.direct_source || ''} poster={selectedStream.stream_icon} />
                            </div>
                            <div className={`h-auto ${currentTheme.colors.sidebar} p-6 border-t border-slate-800`}>
                                <h2 className="text-xl font-bold text-white mb-1">{selectedStream.name}</h2>
                                <div className="flex items-center gap-3 text-sm text-slate-400">
                                    <span className={`${currentTheme.colors.iconBg} ${currentTheme.colors.textAccent} px-2 py-0.5 rounded text-xs font-bold uppercase`}>Live</span>
                                    <span>1080p</span>
                                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Now Playing</span>
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className={`flex-1 flex flex-col items-center justify-center text-slate-600 ${currentTheme.colors.background} p-8 text-center`}>
                            <div className="w-24 h-24 bg-slate-800/50 rounded-full flex items-center justify-center mb-6">
                                <Tv className="w-10 h-10 opacity-30" />
                            </div>
                            <h3 className="text-lg font-medium text-slate-400">Select a channel to start watching</h3>
                            <p className="text-sm text-slate-500 mt-2 max-w-xs">Choose from the categories on the left to browse available channels.</p>
                        </div>
                    )}
                </div>
            )}

            {/* --- MOVIES / SERIES VIEW (Grid Layout) --- */}
            {(currentView === 'MOVIES' || currentView === 'SERIES') && (
                <div className="h-full flex flex-col">
                    {/* Filter Bar */}
                    <div className="h-14 border-b border-white/5 bg-slate-900/20 flex items-center px-6 gap-4 overflow-x-auto">
                        <button
                            onClick={() => setSelectedCategory(null)}
                            className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-bold transition-all ${!selectedCategory ? `${currentTheme.colors.bgAccent} text-white` : 'bg-slate-800 text-slate-400 hover:text-white'}`}
                        >
                            All
                        </button>
                        {activeCategories.map(cat => (
                             <button
                                key={cat.category_id}
                                onClick={() => setSelectedCategory(cat.category_id)}
                                className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-bold transition-all ${selectedCategory === cat.category_id ? `${currentTheme.colors.bgAccent} text-white` : 'bg-slate-800 text-slate-400 hover:text-white'}`}
                            >
                                {cat.category_name}
                            </button>
                        ))}
                    </div>

                    {selectedStream ? (
                        /* Detail / Player View for VOD */
                        <div className={`flex-1 ${currentTheme.colors.sidebar} overflow-y-auto`}>
                            <div className="relative h-[50vh] w-full">
                                <div className="absolute inset-0">
                                    <VideoPlayer 
                                        key={selectedStream.stream_id} 
                                        src={selectedStream.direct_source || ''} 
                                        poster={selectedStream.stream_icon} 
                                        onProgress={handleStreamProgress}
                                    />
                                </div>
                                <button 
                                    onClick={() => setSelectedStream(null)}
                                    className="absolute top-6 left-6 z-20 bg-black/50 hover:bg-black/80 text-white p-2 rounded-full backdrop-blur-md transition-all"
                                >
                                    <ArrowLeft className="w-6 h-6" />
                                </button>
                            </div>
                            <div className="p-8 max-w-5xl mx-auto">
                                <div className="flex flex-col md:flex-row gap-8">
                                    <img src={selectedStream.stream_icon} className="w-48 h-72 rounded-xl object-cover shadow-2xl shadow-black/50 hidden md:block" />
                                    <div>
                                        <h1 className="text-4xl font-bold text-white mb-4">{selectedStream.name}</h1>
                                        <div className="flex items-center gap-4 mb-6">
                                            <span className="flex items-center text-yellow-400 font-bold"><Star className="w-4 h-4 fill-current mr-1" /> {selectedStream.rating || 'N/A'}</span>
                                            <span className="text-slate-400 text-sm">{currentView === 'MOVIES' ? '2023 • 2h 14m' : '3 Seasons'}</span>
                                            <span className="border border-slate-600 px-2 py-0.5 rounded text-xs text-slate-300">HD</span>
                                        </div>
                                        {/* Dynamic Progress indicator if playing */}
                                        {selectedStream.progress && selectedStream.progress > 0 && (
                                            <div className="mb-6 w-full max-w-md">
                                                <div className="flex justify-between text-xs text-slate-400 mb-1">
                                                    <span>Resume watching</span>
                                                    <span>{selectedStream.progress}% complete</span>
                                                </div>
                                                <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                                                    <div className={`h-full ${currentTheme.colors.bgAccent}`} style={{ width: `${selectedStream.progress}%` }}></div>
                                                </div>
                                            </div>
                                        )}

                                        <p className="text-slate-300 leading-relaxed text-lg mb-8">
                                            Experience high-definition streaming with {selectedStream.name}. 
                                            This content is streamed directly from our secure XTream Codes compatible servers.
                                            Enjoy buffer-free playback and crystal clear audio.
                                        </p>
                                        <div className="flex gap-4">
                                            <button className={`${currentTheme.colors.bgAccent} text-white px-6 py-3 rounded-lg font-bold flex items-center gap-2 hover:opacity-90 transition-opacity`}>
                                                <Play className="w-5 h-5 fill-current" /> {selectedStream.progress && selectedStream.progress > 0 ? 'Resume' : 'Play'}
                                            </button>
                                            <button className="bg-slate-800 text-white px-6 py-3 rounded-lg font-bold flex items-center gap-2 hover:bg-slate-700 transition-colors">
                                                <Info className="w-5 h-5" /> More Info
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ) : (
                        /* Grid View */
                        <div className="flex-1 overflow-y-auto p-6">
                            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
                                {filteredStreams.map(stream => (
                                    <div 
                                        key={stream.stream_id}
                                        onClick={() => setSelectedStream(stream)}
                                        className="group cursor-pointer flex flex-col"
                                    >
                                        <div className={`relative aspect-[2/3] rounded-xl overflow-hidden mb-3 ${currentTheme.colors.cardBg} shadow-lg group-hover:shadow-2xl transition-all duration-300 group-hover:-translate-y-2`}>
                                            <img src={stream.stream_icon} alt={stream.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                                                <div className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center mx-auto mb-2 transform scale-0 group-hover:scale-100 transition-transform delay-100">
                                                    <Play className="w-4 h-4 fill-current ml-0.5" />
                                                </div>
                                            </div>
                                            {stream.rating && (
                                                <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-1.5 py-0.5 rounded text-[10px] font-bold text-yellow-400 flex items-center">
                                                    <Star className="w-3 h-3 fill-current mr-0.5" /> {stream.rating}
                                                </div>
                                            )}
                                            {/* Grid Item Progress Bar */}
                                            {stream.progress && stream.progress > 0 && (
                                                <div className="absolute bottom-0 left-0 right-0 h-1 bg-slate-700/50">
                                                    <div className={`h-full ${currentTheme.colors.bgAccent}`} style={{ width: `${stream.progress}%` }}></div>
                                                </div>
                                            )}
                                        </div>
                                        <h3 className="text-sm font-medium text-slate-300 truncate group-hover:text-white transition-colors">{stream.name}</h3>
                                    </div>
                                ))}
                            </div>
                            {filteredStreams.length === 0 && (
                                <div className="h-full flex items-center justify-center text-slate-500">
                                    No content found.
                                </div>
                            )}
                        </div>
                    )}
                </div>
            )}

            {/* --- AI SEARCH VIEW --- */}
            {currentView === 'AI_SEARCH' && (
                <div className="max-w-4xl mx-auto p-6 flex flex-col h-full">
                    <div className={`flex-1 overflow-y-auto mb-6 ${currentTheme.colors.cardBg} rounded-3xl p-8 border border-white/5 shadow-2xl`}>
                        {aiResponse ? (
                            <div className="flex items-start gap-6 animate-fadeIn">
                                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${currentTheme.colors.gradient} flex items-center justify-center shrink-0 shadow-lg`}>
                                    <Sparkles className="w-6 h-6 text-white" />
                                </div>
                                <div className="space-y-4 flex-1">
                                    <h3 className={`font-bold text-lg ${currentTheme.colors.textAccent}`}>Genie Suggests:</h3>
                                    <div className="text-slate-300 leading-relaxed whitespace-pre-line text-lg">
                                        {aiResponse}
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div className="h-full flex flex-col items-center justify-center text-center">
                                <div className={`w-20 h-20 ${currentTheme.colors.iconBg} rounded-full flex items-center justify-center mb-6 animate-pulse`}>
                                    <Sparkles className={`w-10 h-10 ${currentTheme.colors.textAccent}`} />
                                </div>
                                <h3 className="text-2xl font-bold text-white mb-3">AI Content Curator</h3>
                                <p className="text-slate-400 max-w-md">
                                    "I'm in the mood for an 80s action movie with a high rating" <br/>
                                    "Show me sports channels showing football"
                                </p>
                            </div>
                        )}
                    </div>

                    <div className="relative group">
                        <input
                            type="text"
                            value={aiQuery}
                            onChange={(e) => setAiQuery(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleAskAI()}
                            placeholder="Ask Genie for recommendations..."
                            className={`w-full ${currentTheme.colors.cardBg} border border-slate-700/50 rounded-2xl py-5 pl-6 pr-16 text-white placeholder-slate-500 focus:outline-none focus:${currentTheme.colors.borderAccent} focus:ring-1 focus:ring-opacity-50 transition-all shadow-xl`}
                        />
                        <button 
                            onClick={handleAskAI}
                            disabled={aiLoading}
                            className={`absolute right-3 top-3 bottom-3 ${currentTheme.colors.bgAccent} hover:opacity-90 text-white p-3 rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed aspect-square flex items-center justify-center shadow-lg`}
                        >
                            {aiLoading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Send className="w-5 h-5" />}
                        </button>
                    </div>
                </div>
            )}

            {/* --- SETTINGS / THEMES VIEW --- */}
            {currentView === 'SETTINGS' && (
                <div className="p-8 h-full overflow-y-auto">
                    <div className="max-w-5xl mx-auto">
                        <div className="mb-8">
                            <h2 className="text-2xl font-bold text-white mb-2 flex items-center">
                                <Palette className={`w-6 h-6 mr-3 ${currentTheme.colors.textAccent}`} />
                                Appearance
                            </h2>
                            <p className="text-slate-400">Customize the look and feel of your player.</p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {APP_THEMES.map(theme => (
                                <div 
                                    key={theme.id}
                                    onClick={() => setCurrentTheme(theme)}
                                    className={`
                                        cursor-pointer rounded-2xl p-6 border-2 transition-all relative overflow-hidden group
                                        ${theme.id === currentTheme.id ? `border-${theme.colors.borderAccent.split('-')[1]}-${theme.colors.borderAccent.split('-')[2]} ${theme.colors.cardBg}` : 'border-transparent bg-slate-800/50 hover:bg-slate-800'}
                                    `}
                                >
                                    <div className="flex items-center justify-between mb-4 relative z-10">
                                        <span className="font-bold text-lg text-white">{theme.name}</span>
                                        {theme.id === currentTheme.id && <Check className={`w-6 h-6 ${theme.colors.textAccent}`} />}
                                    </div>
                                    
                                    <div className="flex gap-2 mb-4 relative z-10">
                                        <div className={`w-8 h-8 rounded-full ${theme.colors.bgAccent}`}></div>
                                        <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${theme.colors.gradient}`}></div>
                                        <div className={`w-8 h-8 rounded-full ${theme.colors.sidebar} border border-white/10`}></div>
                                    </div>

                                    {/* Theme Preview Background */}
                                    <div className={`absolute inset-0 opacity-20 bg-gradient-to-br ${theme.colors.gradient} group-hover:opacity-30 transition-opacity`}></div>
                                </div>
                            ))}
                        </div>

                        <div className="mt-12 p-6 rounded-2xl bg-white/5 border border-white/5">
                            <h3 className="text-lg font-bold text-white mb-4">Application Settings</h3>
                            <div className="space-y-4">
                                <div className="flex items-center justify-between p-4 rounded-xl bg-black/20">
                                    <div>
                                        <div className="font-medium text-white">Stream Quality</div>
                                        <div className="text-xs text-slate-500">Preferred playback resolution</div>
                                    </div>
                                    <select className="bg-slate-800 text-white text-sm rounded-lg px-3 py-2 border border-slate-700 outline-none">
                                        <option>Auto</option>
                                        <option>1080p</option>
                                        <option>720p</option>
                                    </select>
                                </div>
                                <div className="flex items-center justify-between p-4 rounded-xl bg-black/20">
                                    <div>
                                        <div className="font-medium text-white">Parental Control</div>
                                        <div className="text-xs text-slate-500">Pin protect adult content</div>
                                    </div>
                                    <button className="text-sm bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-lg text-white transition-colors">Setup PIN</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
      </main>
    </div>
  );
};

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element");
}
const root = createRoot(rootElement);
root.render(<App />);