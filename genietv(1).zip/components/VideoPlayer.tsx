import React, { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';
import { Play, Pause, Volume2, VolumeX, Maximize, Loader2 } from 'lucide-react';

interface VideoPlayerProps {
  src: string;
  poster?: string;
  autoPlay?: boolean;
  onProgress?: (percentage: number) => void;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ src, poster, autoPlay = true, onProgress }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let hls: Hls | null = null;
    const video = videoRef.current;

    if (!video) return;

    setIsLoading(true);
    setError(null);

    const handleReady = () => {
      setIsLoading(false);
      if (autoPlay) {
        video.play().catch(e => {
            console.warn("Autoplay blocked", e);
            setIsPlaying(false);
        });
      }
    };

    const handleTimeUpdate = () => {
        if (onProgress && video.duration) {
            const percentage = (video.currentTime / video.duration) * 100;
            if (!isNaN(percentage)) {
                onProgress(Math.floor(percentage));
            }
        }
    };

    video.addEventListener('timeupdate', handleTimeUpdate);

    if (Hls.isSupported()) {
      hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
      });
      
      hls.loadSource(src);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        handleReady();
      });

      hls.on(Hls.Events.ERROR, (event, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              hls?.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls?.recoverMediaError();
              break;
            default:
              setError("Stream error. This might be due to CORS or an invalid URL.");
              setIsLoading(false);
              hls?.destroy();
              break;
          }
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      // Native HLS support (Safari)
      video.src = src;
      video.addEventListener('loadedmetadata', handleReady);
      video.addEventListener('error', () => {
          setError("Native playback error.");
          setIsLoading(false);
      });
    } else {
      setError("HLS is not supported in this browser.");
      setIsLoading(false);
    }

    return () => {
      if (hls) {
        hls.destroy();
      }
      if(video) {
          video.removeEventListener('loadedmetadata', handleReady);
          video.removeEventListener('timeupdate', handleTimeUpdate);
      }
    };
  }, [src, autoPlay, onProgress]);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const toggleFullscreen = () => {
    if (videoRef.current) {
      if (document.fullscreenElement) {
        document.exitFullscreen();
      } else {
        videoRef.current.requestFullscreen();
      }
    }
  };

  return (
    <div className="relative group w-full h-full bg-black overflow-hidden rounded-lg shadow-2xl">
      {isLoading && !error && (
        <div className="absolute inset-0 flex items-center justify-center z-20 bg-black/50">
          <Loader2 className="w-10 h-10 text-cyan-500 animate-spin" />
        </div>
      )}
      
      {error && (
        <div className="absolute inset-0 flex items-center justify-center z-20 bg-black/80 text-white p-4 text-center">
          <div>
            <p className="text-red-500 font-bold mb-2">Playback Error</p>
            <p className="text-sm text-gray-300">{error}</p>
          </div>
        </div>
      )}

      <video
        ref={videoRef}
        poster={poster}
        className="w-full h-full object-contain"
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
      />

      {/* Controls Overlay */}
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button onClick={togglePlay} className="text-white hover:text-cyan-400 transition-colors">
              {isPlaying ? <Pause size={24} /> : <Play size={24} />}
            </button>
            <button onClick={toggleMute} className="text-white hover:text-cyan-400 transition-colors">
              {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
            </button>
          </div>
          <button onClick={toggleFullscreen} className="text-white hover:text-cyan-400 transition-colors">
            <Maximize size={24} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;